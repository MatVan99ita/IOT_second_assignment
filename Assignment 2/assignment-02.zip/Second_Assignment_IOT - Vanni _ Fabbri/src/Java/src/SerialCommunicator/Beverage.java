package SerialCommunicator;

public interface Beverage {
	void makeBeverage();
	void refill();
}
